-- Add Dimension Read User
CREATE USER ${tenant_name}_dim_db_reader with PASSWORD '${tenant_dim_db_reader_user_password}';

ALTER USER ${tenant_name}_dim_db_reader SET enable_case_sensitive_identifier TO true;