DROP MATERIALIZED VIEW IF EXISTS ${schema_name}.action_state_fact;
CREATE MATERIALIZED VIEW ${schema_name}.action_state_fact
    DISTKEY (id)
    SORTKEY (id, state_id)
    AUTO REFRESH YES AS
    SELECT data.id::bigint as id,
        datetime_id,
        state_id
    FROM ${schema_name}.timeseries t INNER JOIN ${schema_name}.datetime_dim dt ON t.data.ts::timestamp = dt.datetime
        INNER JOIN ${schema_name}.action_state_dim s ON t.data.state::varchar = state
    WHERE data."recordType"='action_state';