-- Remove group types from entity type enums
DELETE FROM ${schema_name}.entity_type_dim 
	WHERE type in (
		'GROUP', 
		'RESOURCE_GROUP', 
		'COMPUTE_CLUSTER', 
		'K8S_CLUSTER', 
		'STORAGE_CLUSTER', 
		'BILLING_FAMILY'
	);

-- Create a copy of entity type enums for related_entity_view
CREATE OR REPLACE VIEW ${schema_name}.related_entity_type_dim AS
	SELECT * FROM ${schema_name}.entity_type_dim;