DROP MATERIALIZED VIEW IF EXISTS ${schema_name}.workload_controller_attrs_dim;
CREATE MATERIALIZED VIEW ${schema_name}.workload_controller_attrs_dim
    DISTKEY (action_id)
    SORTKEY (action_id, first_seen)
    AUTO REFRESH YES AS
SELECT data.action_id::bigint,
        data.namespace::varchar,
        data.container_cluster::varchar,
        data.replica_count::int,
        t.data.md5::varchar as md5,
        t.data.ts::timestamp as first_seen
FROM ${schema_name}.timeseries t
    WHERE data."recordType"='workload_controller_attrs';
