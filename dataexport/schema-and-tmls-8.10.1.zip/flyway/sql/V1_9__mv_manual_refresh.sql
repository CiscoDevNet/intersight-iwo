-- This will create a stored procedure in the schema ${schema_name} 
-- to refresh all the materialized views in the database 
-- that have not been refreshed in the last 24 hours.
-- The stored procedure will be called at regular intervals using a lambda.

CREATE OR REPLACE PROCEDURE ${schema_name}.sp_refresh_all_mv()
AS $$
DECLARE
    t_view_name varchar;
	curs1 CURSOR FOR select schema_name || '.' || mv_name as view_name
        from (select schema_name, mv_name, max(starttime) as max_starttime
            from svl_mv_refresh_status a
            inner join (select schema from stv_mv_info) b on a.schema_name = b.schema
            group by schema_name, mv_name)
        where max_starttime <= dateadd(day,-1,getdate())

        union

        select schema || '.' || name as view_name
            from stv_mv_info 
            where schema || '.' || name not in (
                select schema_name || '.' || mv_name 
                from svl_mv_refresh_status);
BEGIN
	OPEN curs1;
	LOOP
		FETCH curs1 into t_view_name;
		EXIT WHEN NOT FOUND;
        RAISE INFO 'Refreshing %', t_view_name;
		EXECUTE 'REFRESH MATERIALIZED VIEW ' || t_view_name || ';';
	END LOOP;
	CLOSE curs1;
END;
$$ LANGUAGE plpgsql;