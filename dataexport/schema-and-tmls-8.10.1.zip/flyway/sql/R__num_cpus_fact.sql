DROP MATERIALIZED VIEW IF EXISTS ${schema_name}.num_cpus_fact;
CREATE MATERIALIZED VIEW ${schema_name}.num_cpus_fact
    AUTO REFRESH YES AS
    SELECT data.id::bigint as id,
        datetime_id,
        data.num_cpus::int
    FROM ${schema_name}.timeseries t INNER JOIN ${schema_name}.datetime_dim dt ON t.data.ts::timestamp = dt.datetime
    WHERE data."recordType"='num_cpus';