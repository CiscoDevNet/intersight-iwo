-- We define a stored procedure to drop materialized views in a safe way.
-- It will first verify that the supplied view name corresponds to a materialized
-- view, before attempting to drop it.
CREATE OR REPLACE PROCEDURE ${schema_name}.sp_drop_mv(view_name VARCHAR) 
AS $$
DECLARE
    temp record;
BEGIN
    SELECT count(*) AS r_count INTO temp FROM stv_mv_info WHERE schema = '${schema_name}' AND name = view_name;
    IF temp.r_count >= 1 THEN
        EXECUTE 'DROP MATERIALIZED VIEW ${schema_name}.' || quote_ident(view_name);
    END IF;
END;
$$ 
LANGUAGE plpgsql;

-- Entity and Group dimension used to be materialized views instead of standard ones.
-- Running the migrations on a tenant that still has those two as materialized views
-- will fail. We make sure to remove those MVs before migrating the schema to avoid
-- any problems. 
CALL ${schema_name}.sp_drop_mv('entity_dim');
CALL ${schema_name}.sp_drop_mv('group_dim');