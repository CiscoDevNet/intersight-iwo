-- Internal materialized view that separates all the action records from
-- the timeseries table.
DROP MATERIALIZED VIEW IF EXISTS ${schema_name}.action_hist_internal;
CREATE MATERIALIZED VIEW ${schema_name}.action_hist_internal 
    DISTKEY (id)
    SORTKEY (id, first_seen)
    AUTO REFRESH YES AS
    SELECT data.id::bigint as id,
        t.data.md5::varchar as md5,
        t.data.ts::timestamp as first_seen,
        data.recommendation_time::timestamp as creation_time,
        data.description::varchar,
        data.explanation::varchar,
        type_id::int,
        category_id::int,
        mode_id::int,
        severity_id::int,
        data.target_type::varchar,
        data.target_name::varchar,
        environment_id::int,
        data.user_account::varchar,
        data.execution_time::timestamp,
        data.execution_error::varchar,
        data.moveinfo_destination_type::varchar,
        data.deleteinfo_filepath::varchar,
        data.deleteinfo_filesize::float,
        data.resizeinfo_commodity::varchar,
        data.resizeinfo_oldcapacity::float,
        data.resizeinfo_newcapacity::float,
        data.resizeinfo_target_name::varchar,
        data.resizeinfo_target_type::varchar,
        data.resizeinfo_unit::varchar
    FROM ${schema_name}.timeseries t 
        INNER JOIN ${schema_name}.action_type_dim at ON t.data.type:: varchar = at.type
        INNER JOIN ${schema_name}.action_category_dim ac ON t.data.category:: varchar = ac.category
        INNER JOIN ${schema_name}.action_mode_dim am ON t.data.mode:: varchar = am.mode
        INNER JOIN ${schema_name}.action_severity_dim asev ON t.data.severity:: varchar = asev.severity
        INNER JOIN ${schema_name}.entity_environment_dim env ON t.data.environment:: varchar = env.environment
    WHERE data."recordType"='action';


-- Standard view for the action_dim
-- Does a self join on action_hist_internal to present the current actions
-- in the tenant's environment
CREATE OR REPLACE VIEW ${schema_name}.action_dim
AS  SELECT ah.id::bigint as id,
    ah.md5::varchar,
    ah.first_seen::timestamp,
    ah.creation_time::timestamp,
    ah.description::varchar,
    ah.explanation::varchar,
    ah.type_id::int,
    ah.category_id::int,
    ah.mode_id::int,
    ah.severity_id::int,
    ah.target_type::varchar,
    ah.target_name::varchar,
    ah.environment_id::int,
    ah.moveinfo_destination_type::varchar,
    ah.deleteinfo_filepath::varchar,
    ah.deleteinfo_filesize::float,
    ah.resizeinfo_commodity::varchar,
    ah.resizeinfo_oldcapacity::float,
    ah.resizeinfo_newcapacity::float,
    ah.resizeinfo_target_name::varchar,
    ah.resizeinfo_target_type::varchar,
    ah.resizeinfo_unit::varchar,
    ah.user_account::varchar,
    ah.execution_time::timestamp,
    ah.execution_error::varchar
FROM ${schema_name}.action_hist_internal ah INNER JOIN
    (SELECT id AS id, 
        max(first_seen) AS max_first_seen 
    FROM ${schema_name}.action_hist_internal
    GROUP BY 1
    ORDER BY 1, 2) latest ON ah.id = latest.id AND ah.first_seen >= latest.max_first_seen
WITH NO SCHEMA BINDING;