-- Add Read User
CREATE USER ${tenant_name}_db_reader PASSWORD DISABLE;

GRANT SELECT ON ALL TABLES IN SCHEMA ${schema_name} TO ${tenant_name}_db_reader;

GRANT USAGE ON SCHEMA ${schema_name} TO ${tenant_name}_db_reader;

ALTER USER ${tenant_name}_db_reader SET enable_case_sensitive_identifier TO true;

-- Add Write User
CREATE USER ${tenant_name}_db_writer with PASSWORD '${tenant_db_writer_user_password}';

GRANT USAGE ON SCHEMA ${schema_name} TO ${tenant_name}_db_writer;

GRANT INSERT ON ALL TABLES IN SCHEMA ${schema_name} TO ${tenant_name}_db_writer;

