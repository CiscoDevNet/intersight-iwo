-- Clean up
-- Remove the group_dim mv and v (If already created)
-- DROP MATERIALIZED VIEW IF EXISTS ${schema_name}.group_dim;

-- Internal materialized view that separates all the entity records from
-- the timeseries table.
DROP MATERIALIZED VIEW IF EXISTS ${schema_name}.group_hist_internal;
CREATE MATERIALIZED VIEW ${schema_name}.group_hist_internal 
    DISTKEY (id)
    SORTKEY (id, first_seen)
    AUTO REFRESH YES AS
SELECT t.data.id::bigint as id,
    t.data.name::varchar as name,
    t.data.dynamic::boolean as is_dynamic,
    gt.type_id::int as type_id,
    go.origin_id::int as origin_id,
    et.type_id::int as "member_type_id",
    t.data.md5::varchar as md5,
    t.data.ts::timestamp as first_seen
FROM ${schema_name}.timeseries t
    INNER JOIN ${schema_name}.group_type_dim gt ON t.data.type:: varchar = gt.type
    INNER JOIN ${schema_name}.group_origin_dim go ON t.data.origin:: varchar = go.origin
    INNER JOIN ${schema_name}.entity_type_dim et ON t.data."member_type":: varchar = et.type
WHERE data."recordType" = 'group';

-- Standard view for the group_dim
-- Does a self join on group_hist_internal to present the current groups
-- in the tenant's environment
CREATE OR REPLACE VIEW ${schema_name}.group_dim
AS SELECT gh.id::bigint as id,
    gh.name::varchar as name,
    gh.is_dynamic::boolean as is_dynamic,
    gh.type_id::int as type_id,
    gh.origin_id::int as origin_id,
    gh.member_type_id::int as member_type_id,
    gh.md5::varchar as md5,
    gh.first_seen::timestamp as first_seen
FROM ${schema_name}.group_hist_internal gh INNER JOIN
    (SELECT id AS id, 
        max(first_seen) AS max_first_seen 
    FROM ${schema_name}.group_hist_internal
    GROUP BY 1
    ORDER BY 1, 2) latest ON gh.id = latest.id AND gh.first_seen >= latest.max_first_seen
WITH NO SCHEMA BINDING;