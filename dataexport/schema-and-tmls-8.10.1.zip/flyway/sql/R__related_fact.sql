DROP MATERIALIZED VIEW IF EXISTS ${schema_name}.related_fact;
CREATE MATERIALIZED VIEW ${schema_name}.related_fact
    AUTO REFRESH YES AS 
    SELECT data.source_id::bigint as source_id,
        datetime_id,
        data.related_id::bigint as related_id
    FROM ${schema_name}.timeseries t INNER JOIN ${schema_name}.datetime_dim dt ON t.data.ts::timestamp = dt.datetime
    WHERE data."recordType"='relationship';