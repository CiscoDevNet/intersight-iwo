-- Action-specific dimensions
----------------------------------

DROP TABLE IF EXISTS ${schema_name}.action_state_dim;
CREATE TABLE ${schema_name}.action_state_dim(
    state_id int identity (1,1),
    "state" varchar
) DISTSTYLE ALL
COMPOUND SORTKEY (state);
INSERT INTO ${schema_name}.action_state_dim (state) VALUES 
	('READY'),
	('CLEARED'),
	('REJECTED'),
	('ACCEPTED'),
	('QUEUED'),
	('PRE_IN_PROGRESS'),
	('IN_PROGRESS'),
	('POST_IN_PROGRESS'),
	('FAILING'),
	('SUCCEEDED'),
	('FAILED');

DROP TABLE IF EXISTS ${schema_name}.action_type_dim;
CREATE TABLE ${schema_name}.action_type_dim(
	type_id int identity (1,1),
	"type" varchar
) DISTSTYLE ALL
COMPOUND SORTKEY (type);
INSERT INTO ${schema_name}.action_type_dim (type) VALUES
	('NONE'),
	('START'),
	('MOVE'),
	('SUSPEND'),
	('PROVISION'),
	('RECONFIGURE'),
	('RESIZE'),
	('ACTIVATE'),
	('DEACTIVATE'),
	('DELETE'),
	('BUY_RI'),
	('SCALE'),
	('ALLOCATE');

DROP TABLE IF EXISTS ${schema_name}.action_mode_dim;
CREATE TABLE ${schema_name}.action_mode_dim(
	mode_id int identity (1,1),
	"mode" varchar
) DISTSTYLE ALL
COMPOUND SORTKEY (mode);
INSERT INTO ${schema_name}.action_mode_dim (mode) VALUES
 	('DISABLED'),
	('RECOMMEND'),
	('EXTERNAL_APPROVAL'),
	('MANUAL'),
	('AUTOMATIC');

DROP TABLE IF EXISTS ${schema_name}.action_category_dim;
CREATE TABLE ${schema_name}.action_category_dim(
	category_id int identity (1,1),
	"category" varchar
) DISTSTYLE ALL
COMPOUND SORTKEY (category);
INSERT INTO ${schema_name}.action_category_dim (category) VALUES
 	('UNKNOWN'),
	('PERFORMANCE_ASSURANCE'),
	('EFFICIENCY_IMPROVEMENT'),
	('PREVENTION'),
	('COMPLIANCE'),
	('SAVING');

DROP TABLE IF EXISTS ${schema_name}.action_severity_dim;
CREATE TABLE ${schema_name}.action_severity_dim(
	severity_id int identity (1,1),
	"severity" varchar
) DISTSTYLE ALL
COMPOUND SORTKEY (severity);
INSERT INTO ${schema_name}.action_severity_dim (severity) VALUES
 	('NORMAL'),
	('MINOR'),
	('MAJOR'),
	('CRITICAL');