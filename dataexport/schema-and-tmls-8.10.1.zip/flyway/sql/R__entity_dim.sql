-- Clean up
-- Remove the entity_dim mv and v (If already created)
-- DROP MATERIALIZED VIEW IF EXISTS ${schema_name}.entity_dim;

-- Internal materialized view that separates all the entity records from
-- the timeseries table.
DROP MATERIALIZED VIEW IF EXISTS ${schema_name}.entity_hist_internal;
CREATE MATERIALIZED VIEW ${schema_name}.entity_hist_internal 
    DISTKEY (id)
    SORTKEY (id, first_seen)
    AUTO REFRESH YES AS
SELECT t.data.id::bigint as id, 
    t.data.name::varchar as name,
    et.type_id::int as type_id,
    ev.environment_id::int as environment_id,
    t.data.md5::varchar as md5,
    t.data.ts::timestamp as first_seen
FROM ${schema_name}.timeseries t    
    INNER JOIN ${schema_name}.entity_type_dim et ON t.data.type::varchar = et.type
    INNER JOIN ${schema_name}.entity_environment_dim ev ON t.data.environment::varchar = ev.environment
WHERE data."recordType"='entity';

-- Standard view for the entity_dim
-- Does a self join on entity_hist_internal to present the current entities
-- in the tenant's environment
CREATE OR REPLACE VIEW ${schema_name}.entity_dim
AS SELECT eh.id::bigint as id,
    eh.name::varchar as name,
    eh.type_id::int as type_id,
    eh.environment_id::int as environment_id,
    eh.md5::varchar as md5,
    eh.first_seen::timestamp as first_seen
FROM ${schema_name}.entity_hist_internal eh INNER JOIN
    (SELECT id AS id, 
        max(first_seen) AS max_first_seen 
    FROM ${schema_name}.entity_hist_internal
    GROUP BY 1
    ORDER BY 1, 2) latest ON eh.id = latest.id AND eh.first_seen >= latest.max_first_seen
WITH NO SCHEMA BINDING;