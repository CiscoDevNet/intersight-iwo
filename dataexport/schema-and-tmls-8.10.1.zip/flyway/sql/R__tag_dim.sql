-- Internal materialized view that separates all the tag records from
-- the timeseries table.
DROP MATERIALIZED VIEW IF EXISTS ${schema_name}.tag_hist_internal;
CREATE MATERIALIZED VIEW ${schema_name}.tag_hist_internal 
    DISTKEY (id)
    SORTKEY (id, first_seen)
    AUTO REFRESH YES AS
SELECT t.data.id::bigint as id, 
    t.data.key::varchar as key,
    t.data.value::varchar as value,
    t.data.ts::timestamp as first_seen
FROM ${schema_name}.timeseries t
WHERE data."recordType"='tag';

-- Standard view for the tag_dim
-- Does a self join on tag_hist_internal to present the current tags
-- in the tenant's environment
CREATE OR REPLACE VIEW ${schema_name}.tag_dim
AS SELECT th.id::bigint as id,
    th.key::varchar as key,
    th.value::varchar as value,
    th.first_seen::timestamp as first_seen
FROM ${schema_name}.tag_hist_internal th INNER JOIN
    (SELECT id AS id, 
        max(first_seen) AS max_first_seen 
    FROM ${schema_name}.tag_hist_internal
    GROUP BY 1
    ORDER BY 1, 2) latest ON th.id = latest.id AND th.first_seen >= latest.max_first_seen
WITH NO SCHEMA BINDING;