DROP MATERIALIZED VIEW IF EXISTS ${schema_name}.metric_fact;
CREATE MATERIALIZED VIEW ${schema_name}.metric_fact
    DISTKEY (id)
    SORTKEY (id, datetime_id)
    AUTO REFRESH YES AS 
    SELECT data.id::bigint as id,
        dt.datetime_id as datetime_id,
        mt.type_id as metric_type_id,
        data.capacity::float as capacity,
        data.used::float as used,
        data.utilization::float as utilization,
        data.consumed::float as consumed,
        data.peak_consumed::float as peak_consumed
    FROM ${schema_name}.timeseries t INNER JOIN ${schema_name}.datetime_dim dt ON t.data.ts::timestamp = dt.datetime
        INNER JOIN ${schema_name}.metric_type_dim mt ON t.data."type" = mt.type
    WHERE data."recordType"='metric';