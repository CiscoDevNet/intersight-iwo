-- This migration introduces views that can be used for scoping to entities
-- based on related entity types. For example, the datacenter_view can be used
-- to scope to all entities related to some datacenter.
--
-- We also introduce two stored procedures that can create these views.

-- Creates a view on top of the entity_dim table by selecting all entities
-- with type equals to entity_type_literal
CREATE OR REPLACE PROCEDURE ${schema_name}.sp_create_entity_view(
    view_name varchar, 
    entity_type_literal varchar) 
AS $$
BEGIN
    EXECUTE 
    'CREATE OR REPLACE VIEW ${schema_name}' || '.' || quote_ident(view_name) ||
    ' AS SELECT e.id, e.name' ||
    ' FROM ${schema_name}.entity_dim e' ||
    ' JOIN ${schema_name}.entity_type_dim et ON e.type_id = et.type_id ' ||
    ' WHERE et.type = ' || quote_literal(entity_type_literal) ||
    ' WITH NO SCHEMA BINDING';
END;
$$ 
LANGUAGE plpgsql;

-- Call the stored procedure defined above to create the entity views
CALL ${schema_name}.sp_create_entity_view('host_view', 'PHYSICAL_MACHINE');
CALL ${schema_name}.sp_create_entity_view('vm_view', 'VIRTUAL_MACHINE');
CALL ${schema_name}.sp_create_entity_view('storage_view', 'STORAGE');
CALL ${schema_name}.sp_create_entity_view('datacenter_view', 'DATACENTER');
CALL ${schema_name}.sp_create_entity_view('appication_component_view', 'APPLICATION_COMPONENT');
CALL ${schema_name}.sp_create_entity_view('availability_zone_view', 'AVAILABILITY_ZONE');
CALL ${schema_name}.sp_create_entity_view('business_account_view', 'BUSINESS_ACCOUNT');
CALL ${schema_name}.sp_create_entity_view('business_transaction_view', 'BUSINESS_TRANSACTION');
CALL ${schema_name}.sp_create_entity_view('network_view', 'NETWORK');
CALL ${schema_name}.sp_create_entity_view('region_view', 'REGION');
CALL ${schema_name}.sp_create_entity_view('service_view', 'SERVICE');
CALL ${schema_name}.sp_create_entity_view('service_provider_view', 'SERVICE_PROVIDER');
CALL ${schema_name}.sp_create_entity_view('virtual_volume_view', 'VIRTUAL_VOLUME');


-- Creates a view on top of the group_dim table by selecting all groups
-- with type equals to group_type_literal
CREATE OR REPLACE PROCEDURE ${schema_name}.sp_create_group_view(
    view_name varchar, 
    group_type_literal varchar) 
AS $$
BEGIN
    EXECUTE 
    'CREATE OR REPLACE VIEW ${schema_name}' || '.' || quote_ident(view_name) ||
    ' AS SELECT g.id, g.name' ||
    ' FROM ${schema_name}.group_dim g' ||
    ' JOIN ${schema_name}.group_type_dim gt ON g.type_id = gt.type_id ' ||
    ' WHERE gt.type = ' || quote_literal(group_type_literal) ||
    ' WITH NO SCHEMA BINDING';
END;
$$ 
LANGUAGE plpgsql;


-- Call the stored procedure defined above to create the group views
CALL ${schema_name}.sp_create_group_view('group_view', 'GROUP'); 
CALL ${schema_name}.sp_create_group_view('resource_group_view', 'RESOURCE_GROUP'); 
CALL ${schema_name}.sp_create_group_view('compute_cluster_view', 'COMPUTE_CLUSTER'); 
CALL ${schema_name}.sp_create_group_view('k8s_cluster_view', 'K8S_CLUSTER'); 
CALL ${schema_name}.sp_create_group_view('storage_cluster_view', 'STORAGE_CLUSTER'); 
CALL ${schema_name}.sp_create_group_view('billing_family_view', 'BILLING_FAMILY');