-- Group-specific dimensions
----------------------------------

DROP TABLE IF EXISTS ${schema_name}.group_type_dim;
CREATE TABLE ${schema_name}.group_type_dim(
    type_id int identity (1,1),
    "type" varchar
) DISTSTYLE ALL
COMPOUND SORTKEY (type);
INSERT INTO ${schema_name}.group_type_dim (type) VALUES 
	-- subset of entity_type_dim values 
	('GROUP'), 
	('RESOURCE_GROUP'), 
	('COMPUTE_CLUSTER'), 
	('K8S_CLUSTER'), 
	('STORAGE_CLUSTER'), 
	('BILLING_FAMILY');

DROP TABLE IF EXISTS ${schema_name}.group_origin_dim;
CREATE TABLE ${schema_name}.group_origin_dim(
    origin_id int identity (1,1),
    "origin" varchar
) DISTSTYLE ALL
COMPOUND SORTKEY (origin);
INSERT INTO ${schema_name}.group_origin_dim (origin) VALUES 
	('DISCOVERED'),
	('USER'),
	('SYSTEM');