DROP MATERIALIZED VIEW IF EXISTS ${schema_name}.business_expense_fact;
CREATE MATERIALIZED VIEW ${schema_name}.business_expense_fact
    AUTO REFRESH YES AS
    SELECT 
        data.id::bigint,
        datetime_id::int,
        data.vendor_id::bigint,
        data.expensedate::timestamp,
        data.expensename::varchar,
        data.expenseamount::float, 
        data.expenseunit::varchar
    FROM ${schema_name}.timeseries t INNER JOIN ${schema_name}.datetime_dim dt ON t.data.ts::timestamp = dt.datetime
    WHERE data."recordType"='business_expense';