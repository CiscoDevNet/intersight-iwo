DROP MATERIALIZED VIEW IF EXISTS ${schema_name}.entity_tag_fact;
CREATE MATERIALIZED VIEW ${schema_name}.entity_tag_fact
    DISTKEY (entity_id)
    SORTKEY (entity_id, datetime_id)
    AUTO REFRESH YES AS
    SELECT data.entity_id::bigint as entity_id,
        datetime_id,
        data.id::bigint
    FROM ${schema_name}.timeseries t INNER JOIN ${schema_name}.datetime_dim dt ON t.data.ts::timestamp = dt.datetime
    WHERE data."recordType"='entity_tag';