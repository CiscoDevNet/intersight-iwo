DROP MATERIALIZED VIEW IF EXISTS ${schema_name}.action_related_fact;
CREATE MATERIALIZED VIEW ${schema_name}.action_related_fact
    DISTKEY (related_id)
    SORTKEY (related_id, source_id)
    AUTO REFRESH YES AS 
    SELECT data.source_id::bigint as source_id,
        datetime_id,
        data.related_id::bigint as related_id,
        data.is_target::boolean
    FROM ${schema_name}.timeseries t INNER JOIN ${schema_name}.datetime_dim dt ON t.data.ts::timestamp = dt.datetime
    WHERE data."recordType"='action_relationship';