-- Common datetime dimension
----------------------------

drop table if exists ${schema_name}.datetime_dim;
create table ${schema_name}.datetime_dim(
    datetime_id int,
    datetime timestamp  -- minute granularity
);


-- Initialize the datetime_dim table
------------------------------------

drop table if exists ${schema_name}.digits;
create table ${schema_name}.digits (number smallint);
insert into ${schema_name}.digits (number) values (0), (1), (2), (3), (4), (5), (6), (7), (8), (9);

drop table if exists ${schema_name}.numbers;
create table ${schema_name}.numbers (number bigint);
insert into ${schema_name}.numbers
(
    select millions.number * 1000000 + hundrend_thousands.number * 100000 + ten_thousands.number * 10000 + thousands.number * 1000 + hundrends.number * 100 + tens.number * 10 + ones.number as number
    from ${schema_name}.digits millions, ${schema_name}.digits hundrend_thousands, ${schema_name}.digits ten_thousands, ${schema_name}.digits thousands, ${schema_name}.digits hundrends, ${schema_name}.digits tens, ${schema_name}.digits ones 
    order by 1 
    limit 525600 * 5
);

insert into ${schema_name}.datetime_dim (datetime_id, datetime)
( 
    select
    ROW_NUMBER() OVER(ORDER BY ts) as d_id,
    '2023-01-01 00:00:00':: TIMESTAMP + (n.number || 'minute')::interval AS ts
    from ${schema_name}.numbers as n
);

drop table ${schema_name}.numbers;
drop table ${schema_name}.digits;