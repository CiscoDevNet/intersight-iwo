-- The table targeted by ingestion
----------------------------------

CREATE TABLE IF NOT EXISTS ${schema_name}.timeseries (
	data super
);


-- Enumerations
---------------

DROP TABLE IF EXISTS ${schema_name}.entity_state_dim;
CREATE TABLE ${schema_name}.entity_state_dim(
    state_id int identity (1,1),
    "state" varchar
) DISTSTYLE ALL
COMPOUND SORTKEY (state);
INSERT INTO ${schema_name}.entity_state_dim (state) VALUES 
	('POWERED_ON'), 
	('POWERED_OFF'), 
	('SUSPENDED'), 
	('MAINTENANCE'), 
	('FAILOVER'), 
	('UNKNOWN');

DROP TABLE IF EXISTS ${schema_name}.entity_type_dim;
CREATE TABLE ${schema_name}.entity_type_dim(
    type_id int identity (1,1),
    "type" varchar
) DISTSTYLE ALL
COMPOUND SORTKEY (type);
INSERT INTO ${schema_name}.entity_type_dim (type) VALUES 
    ('APPLICATION'),
    ('APPLICATION_COMPONENT'), 
	('BUSINESS_ACCOUNT'), 
	('BUSINESS_APPLICATION'), 
	('BUSINESS_TRANSACTION'), 
	('BUSINESS_USER'), 
	('CHASSIS'), 
	('CONTAINER'), 
	('CONTAINER_POD'), 
	('DATABASE'), 
	('DATABASE_SERVER'), 
	('DATACENTER'), 
	('DESKTOP_POOL'), 
	('DISK_ARRAY'), 
	('IO_MODULE'), 
	('NETWORK'), 
	('REGION'), 
	('PHYSICAL_MACHINE'), 
	('SERVICE'), 
	('STORAGE'), 
	('STORAGE_CONTROLLER'), 
	('SWITCH'), 
	('VIRTUAL_MACHINE'), 
	('VIEW_POD'), 
	('VIRTUAL_VOLUME'), 
    ('CONTAINER_SPEC'), 
	('NAMESPACE'), 
    ('VIRTUAL_DATACENTER'), 
	('WORKLOAD_CONTROLLER'), 
	('ACTION_MANAGER'), 
	('APPLICATION_SERVER'), 
	('AVAILABILITY_ZONE'), 
	('BUSINESS'), 
	('BUSINESS_ENTITY'), 
	('CLOUD_SERVICE'), 
	('COMPUTE_RESOURCE'), 
	('COMPUTE_TIER'), 
	('DATABASE_SERVER_TIER'), 
	('DATABASE_TIER'), 
	('DESIRED_RESERVED_INSTANCE'), 
	('DISTRIBUTED_VIRTUAL_PORTGROUP'), 
	('DPOD'), 
	('HCI_PHYSICAL_MACHINE'), 
	('HYPERVISOR_SERVER'), 
	('INFRASTRUCTURE'), 
	('INTERNET'), 
	('IP'), 
	('LICENSING_SERVICE'), 
	('LOAD_BALANCER'), 
	('LOGICAL_POOL'), 
	('MAC'), 
	('MOVER'), 
	('NETWORKING_ENDPOINT'), 
	('OPERATOR'), 
	('PORT'), 
	('PROCESSOR_POOL'), 
	('RESERVED_INSTANCE'), 
	('RESERVED_INSTANCE_SPECIFICATION'), 
	('RIGHT_SIZER'), 
	('SAVINGS'), 
	('SERVICE_ENTITY_TEMPLATE'), 
	('SERVICE_PROVIDER'), 
	('STORAGE_TIER'), 
	('STORAGE_VOLUME'), 
	('THIS_ENTITY'), 
	('THREE_TIER_APPLICATION'), 
	('VIRTUAL_APPLICATION'), 
	('VLAN'), 
	('VM_SPEC'), 
	('VPOD'), 
	('WEB_SERVER'), 
	('CLOUD_COMMITMENT'), 
	('CONTAINER_PLATFORM_CLUSTER'), 
	('TARGET'), 
	('NODE_POOL'), 
	('APPLICATION_COMPONENT_SPEC'), 
	('VIRTUAL_MACHINE_SPEC'),
    -- these are for group types 
    ('GROUP'), 
	('RESOURCE_GROUP'), 
	('COMPUTE_CLUSTER'), 
	('K8S_CLUSTER'), 
	('STORAGE_CLUSTER'), 
	('BILLING_FAMILY');

DROP TABLE IF EXISTS ${schema_name}.entity_environment_dim;
CREATE TABLE ${schema_name}.entity_environment_dim(
    environment_id int identity (1,1),
    environment varchar
) DISTSTYLE ALL
COMPOUND SORTKEY (environment);
INSERT INTO ${schema_name}.entity_environment_dim (environment) VALUES 
	('UNKNOWN_ENV'), 
	('ON_PREM'), 
	('CLOUD'), 
	('HYBRID');

DROP TABLE IF EXISTS ${schema_name}.metric_type_dim;
CREATE TABLE ${schema_name}.metric_type_dim(
    type_id int identity (1,1),
    "type" varchar
) DISTSTYLE ALL
COMPOUND SORTKEY (type);
INSERT INTO ${schema_name}.metric_type_dim (type) VALUES 
    ('ACTIVE_SESSIONS'), 
	('BALLOONING'), 
	('BUFFER_COMMODITY'), 
	('CONNECTION'), 
	('CPU'), 
	('CPU_ALLOCATION'), 
	('CPU_PROVISIONED'), 
	('DB_CACHE_HIT_RATE'), 
	('DB_MEM'), 
	('EXTENT'), 
	('FLOW'), 
	('FLOW_ALLOCATION'), 
	('HEAP'), 
	('IMAGE_CPU'), 
	('IMAGE_MEM'), 
	('IMAGE_STORAGE'), 
	('IO_THROUGHPUT'), 
	('MEM'), 
	('MEM_ALLOCATION'), 
	('MEM_PROVISIONED'), 
	('NET_THROUGHPUT'), 
	('POOL_CPU'), 
	('POOL_MEM'), 
	('POOL_STORAGE'), 
	('PORT_CHANEL'), 
	('Q1_VCPU'), 
	('Q2_VCPU'), 
	('Q3_VCPU'), 
	('Q4_VCPU'), 
	('Q5_VCPU'), 
	('Q6_VCPU'), 
	('Q7_VCPU'), 
	('Q8_VCPU'), 
	('Q16_VCPU'), 
	('Q32_VCPU'), 
	('Q64_VCPU'), 
	('QN_VCPU'), 
	('REMAINING_GC_CAPACITY'), 
	('RESPONSE_TIME'), 
	('SLA_COMMODITY'), 
	('STORAGE_ACCESS'), 
	('STORAGE_ALLOCATION'), 
	('STORAGE_AMOUNT'), 
	('STORAGE_LATENCY'), 
	('STORAGE_PROVISIONED'), 
	('SWAPPING'), 
	('THREADS'), 
	('TRANSACTION'), 
	('TRANSACTION_LOG'), 
	('VCPU'), 
	('VCPU_LIMIT_QUOTA'), 
	('VCPU_REQUEST'), 
	('VCPU_REQUEST_QUOTA'), 
	('VMEM'), 
	('VMEM_LIMIT_QUOTA'), 
	('VMEM_REQUEST'), 
	('VMEM_REQUEST_QUOTA'), 
	('VSTORAGE'), 
	('TOTAL_SESSIONS'),
    ('CPU_READY'),
    ('CPU_HEADROOM'), 
	('MEM_HEADROOM'), 
	('STORAGE_HEADROOM'), 
	('TOTAL_HEADROOM'), 
	('DTU'), 
	('POWER'), 
	('COOLING'), 
	('ENERGY');
