-- Grant read permissions to db users

GRANT USAGE ON SCHEMA ${schema_name} TO ${tenant_name}_db_reader;
GRANT SELECT ON ALL TABLES IN SCHEMA ${schema_name} TO ${tenant_name}_db_reader;

GRANT USAGE ON SCHEMA ${schema_name} TO ${tenant_name}_db_writer;
GRANT INSERT ON ALL Tables IN SCHEMA ${schema_name} TO ${tenant_name}_db_writer;

-- Add Read-Only User for dimension tables
-- ignoring datetime_dim as it has auto-generated content on create
-- there is no value for dim_reader that is used in Flink to read it.
GRANT USAGE ON SCHEMA ${schema_name} TO ${tenant_name}_dim_db_reader;
GRANT SELECT ON ${schema_name}.entity_dim TO ${tenant_name}_dim_db_reader;
GRANT SELECT ON ${schema_name}.group_dim TO ${tenant_name}_dim_db_reader;
GRANT SELECT ON ${schema_name}.action_dim TO ${tenant_name}_dim_db_reader;
GRANT SELECT ON ${schema_name}.workload_controller_attrs_dim TO ${tenant_name}_dim_db_reader;
ALTER USER ${tenant_name}_db_writer PASSWORD '${tenant_db_writer_user_password}';