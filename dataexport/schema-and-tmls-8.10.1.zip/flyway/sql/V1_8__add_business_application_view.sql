-- Call the stored procedure defined in v1.6 to create the entity view
CALL ${schema_name}.sp_create_entity_view('business_application_view', 'BUSINESS_APPLICATION');
