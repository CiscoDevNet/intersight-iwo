-- Removes the legacy tag records from the timeseries table
DELETE FROM ${schema_name}.timeseries
WHERE data.key is NULL and data."recordType" = 'tag'