-- ADD CARBON METRIC
INSERT INTO ${schema_name}.metric_type_dim (type) VALUES ('CARBON');