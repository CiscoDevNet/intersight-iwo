DROP MATERIALIZED VIEW IF EXISTS ${schema_name}.action_savings_fact;
CREATE MATERIALIZED VIEW ${schema_name}.action_savings_fact
    DISTKEY (datetime_id)
    SORTKEY (datetime_id, savings_hourly)
    AUTO REFRESH YES AS
    SELECT data.id::bigint as id,
        datetime_id,
        data.savings_hourly::float
    FROM ${schema_name}.timeseries t INNER JOIN ${schema_name}.datetime_dim dt ON t.data.ts::timestamp = dt.datetime
    WHERE data."recordType"='action_savings';