-- Generic scoping view
DROP VIEW IF EXISTS ${schema_name}.related_entity_view;
CREATE OR REPLACE VIEW ${schema_name}.related_entity_view AS
	SELECT id, type_id, name
	FROM ${schema_name}.entity_dim
	WITH NO SCHEMA BINDING;